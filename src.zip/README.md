# Transaction Chatbot – Frontend

## Setup
npm install

## Run (dev)
npm run dev

## Build
npm run build
